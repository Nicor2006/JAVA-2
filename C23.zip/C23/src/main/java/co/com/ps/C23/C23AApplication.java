package co.com.ps.C23;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C23AApplication {

	public static void main(String[] args) {
		SpringApplication.run(C23AApplication.class, args);
	}

}
